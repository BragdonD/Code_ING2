#ifndef __ENTETE_H__
#define __ENTETE_H__
#pragma once

#include <iostream>
#include <limits>

int enterInteger();
float enterReal();

#endif